module.exports = {
  port: parseInt(process.env.PORT) || 5000,
  db:
    "mongodb+srv://michal16295:5210521@cluster0.qhqd4.mongodb.net/test?retryWrites=true&w=majority",
};
